# VGPSA ATLAS research draft v0.3 — Change log

Date: 2026-10-20

Scope: Source-reference and axiom-provenance clarification only; no new proof run.

- Added the full explicitly named operational axiom reference FRSA-1 through FRSA-8 (identical in intent to the original SA1–SA8 conditions).
- Added a formal conjunction tying the VGPSA predicate to those conditions and an explicit finite transcript.
- Added the antecedent verifier-gated knowledge relation and conditional temporal receipt-reflection principle from the Self Aware Machine / epistemic-handoff line of work.
- Added a crosswalk matching FRSA-1..8 to the checks for the new P_* witness.
- Added bibliographic entries documenting provenance of original VGPSA v0.1 and the handoff ATLAS revision.
- Corrected one broken section reference, and corrected the revision date to October 20, 2026.

Important distinctions:
- FRSA-1..8 are stipulative, formal operational conditions, NOT axioms of ZFC or universal psychological axioms.
- The ZFC finite-witness result is not presented as verifying the historical September 29 execution.
- The independent checker and stored finite example are carried forward unchanged from v0.2; they were not re-run for this edit.
- There is no proof-assistant-checked ZFC derivation or consciousness claim.

Archive includes the v0.3 PDF and TeX; the v0.2 witness directory is supplied unchanged for reproducibility.
