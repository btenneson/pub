# VGPSA finite ZFC witness v0.2 — reproducibility package

**Scope:** NEW October 20, 2026 finite source-reflection witness. It does NOT certify or reproduce the historical September 29, 2026 experiment.

## What this establishes

* A completely frozen, syntactic key–value source prompt P*.
* A six-field source model and eight source facts, with exact byte-offset evidence.
* A source-sensitive counterfactual edit P*' and a first-level non-target-equivalent source proposition.
* Two concrete certificate/receipt levels c0,r0,c1,r1, with strict stage ordering.
* Independent **program** replay by `independent_verifier.py`, separate from the package-producing script. The verifier recomputes acceptance from the source evidence and checks the first record before the second. Both programs were created in the same environment; this is not third-party certification or a proof-assistant verification of the checker.
* Eight deliberately corrupted candidate packages were rejected.
* An ordinary mathematical proof that a finite witness to the precise `VGPSA_fin` encoding is definable and constructible in ZFC, hence relative consistency with ZFC. The PDF does **not** contain a fully machine-checked formal proof in a ZFC proof assistant.

## Verify

Requires Python 3 and only the standard library.

```bash
python independent_verifier.py
python negative_tests.py
```

To regenerate the certificate package deterministically:

```bash
python build_witness.py
python independent_verifier.py
```

The checksums of frozen source, verifier, producer and certificate package are in `SHA256SUMS.txt`. A passing outcome is `ACCEPT` and `SA1=PASS` through `SA8=PASS`.

## Historical experiment unresolved

The previously archived *Prompt-Reflection Certificate 001 (PRC001)* contains the placeholder `[PASTE THE EXACT FROZEN LEMMA-FISHING PROMPT TO BE STUDIED HERE, WITHOUT EDITING IT AFTER THE EXPERIMENT BEGINS]`. The provided article reports acceptance of c0/c1 but does not include an authentic independently replayable original verifier, complete canonical original prompt bytes, or original receipts. A later source digest remembered from earlier discussions cannot stand in for source bytes or authenticated receipts. Therefore no historical `P0` verdict is claimed by this package.

## Files

- `prompt_P_star.txt` — frozen NEW prompt
- `certificate_package.json` — NEW finite witness, model, source facts, certificates, records, event trace, identities
- `independent_verifier.py` — standalone checker
- `build_witness.py` — package producer
- `negative_tests.py` and `negative_tests.log` — adversarial test harness and output
- `verifier_acceptance.log` — positive acceptance and SA1–SA8 results
- `SHA256SUMS.txt` — checksum manifest
- `formal_addendum.tex` — article's finite formalization and ZFC existence proof (TeX section)

Prepared as an ATLAS-style mathematical repair with ChatGPT assistance; no publication performed.
