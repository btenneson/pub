#!/usr/bin/env python3
"""Independent replay verifier for the NEW finite VGPSA witness.

This script does not call build_witness.py and does not trust user-written
ACCEPT markers without recomputing the underlying certificate checks.
It verifies a deliberately narrow, explicitly fixed finite formalization.
"""
import hashlib, json, pathlib, sys
HERE=pathlib.Path(__file__).resolve().parent
REQUIRED={
'PROMPT_ID':'VGPSA_FINITE_WITNESS_20261020',
'TARGET':'REFUTE_NEGATED_VGPSA_IF_CERTIFIED',
'INSPECTION':'THREE_OR_MORE_SOURCE_FACTS_WITH_EXACT_SPANS',
'MODEL':'FINITE_SOURCE_DERIVED_FACTS',
'DISTINCTION':'P_SOURCE_X_EXECUTION_V_VERIFIER',
'SECOND_LEVEL':'CERTIFY_ACTUAL_ACCEPTED_R0',
'FIRST_CERT':'CHECK_SOURCE_SUPPORTED_NONTRIVIAL_CLAIM',
'SECOND_CERT':'CHECK_RECEIPT_OF_ACTUAL_R0',
'NONTRIVIAL':'NO_TARGET_PREMISE_NO_SELF_LABEL',
'SETTLEMENT':'REFUTE_ONLY_AFTER_TWO_VERIFIED_RECORDS'}

def enc(x): return json.dumps(x,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode('ascii')
def sha(b): return hashlib.sha256(b).hexdigest()
def digest(x):return sha(enc(x))
def require(c,msg):
    if not c:raise ValueError(msg)
def parse(s):
    require(type(s) is str and s.isascii() and s.endswith('\n'),'source must be newline-terminated ASCII')
    lines=s.splitlines()
    require(len(lines)==len(REQUIRED),'wrong field count')
    vals={}
    for line in lines:
        require(line.count('=')==1,'line must have one =')
        k,v=line.split('=')
        require(k not in vals,'duplicate key')
        vals[k]=v
    require(vals==REQUIRED,'source fields do not match frozen P*')
    return vals

def check_span(src, entry):
    require(set(entry)=={'key','value','start','end'},'span schema')
    k=entry['key'];v=entry['value'];a=entry['start'];b=entry['end']
    require(isinstance(a,int) and not isinstance(a,bool) and isinstance(b,int),'span indexes type')
    require(0<=a<b<=len(src),'out of bounds')
    require(src[a:b]==(k+'='+v).encode('ascii'),'byte span differs')
    require(src.count((k+'='+v).encode('ascii'))==1,'not unique exact span')
    return k

def verify(b):
    require(b['schema']=='VGPSA_FINITE_V0_2','unknown schema')
    require(b['historical_run'] is False,'mislabelled historical package')
    p=b['source'].encode('ascii')
    D=parse(b['source'])
    require(b['source_sha256']==sha(p),'source digest incorrect')
    require(b['source']==(HERE/'prompt_P_star.txt').read_text('ascii'),'source not frozen original P*')
    require(b['execution']=={'tag':'X_EXECUTION','producer':'build_witness.py'},'execution identity')
    require(b['verifier']=={'tag':'V_VERIFIER','checker':'independent_verifier.py','checker_sha256':sha(pathlib.Path(__file__).read_bytes())},'verifier identity')
    # SA1: exact source identifier, code source identity, distinct tagged roles.
    require(len({b['execution']['tag'],b['verifier']['tag'],'P_SOURCE'})==3,'non-distinct identity tags')
    # SA2: source facts, including objective and a constraint, with byte-evidence.
    L=b['lemmas'];require(len(L)==8,'expected 8 separate source lemmas')
    ordered=['TARGET','INSPECTION','MODEL','DISTINCTION','SECOND_LEVEL','FIRST_CERT','SECOND_CERT','NONTRIVIAL']
    for i,item in enumerate(L):
        require(item['name']=='L'+str(i+1) and item['kind']=='source_fact','lemma typing')
        require(check_span(p,item['evidence'])==ordered[i],'lemma span does not match required key')
        require(D[item['evidence']['key']]==item['evidence']['value'],'lemma value differs')
    require('TARGET' in ordered and 'NONTRIVIAL' in ordered,'missing objective / constraint')
    # SA3: concrete finite model from the source, with 6 separate facts.
    M=b['model'];modelkeys=['TARGET','INSPECTION','MODEL','DISTINCTION','FIRST_CERT','SECOND_LEVEL']
    require(len(M)==6,'wrong model length')
    for k,entry in zip(modelkeys,M):
        require(check_span(p,entry)==k and D[k]==entry['value'],'model fact not derived from source')
    # SA5: explicit counterfactual edits; compare complete source fields.
    pp=b['counterfactual_source']
    require(type(pp) is str and pp.isascii() and pp.endswith('\n'),'bad P prime')
    expected=b['source'].replace('SECOND_LEVEL=CERTIFY_ACTUAL_ACCEPTED_R0','SECOND_LEVEL=STOP_AFTER_R0').replace('SECOND_CERT=CHECK_RECEIPT_OF_ACTUAL_R0','SECOND_CERT=NOT_REQUIRED').replace('SETTLEMENT=REFUTE_ONLY_AFTER_TWO_VERIFIED_RECORDS','SETTLEMENT=STOP_AFTER_FIRST_VERIFIED_RECORD')
    require(pp==expected and pp!=b['source'],'counterfactual wrong edit')
    require('SECOND_LEVEL=CERTIFY_ACTUAL_ACCEPTED_R0' in b['source'] and 'SECOND_LEVEL=CERTIFY_ACTUAL_ACCEPTED_R0' not in pp,'source sensitive m6 failed')
    # SA6: verify c0 FROM SOURCE, not from an ACCEPT field.
    c0=b['c0'];require(set(c0)=={'id','source_sha256','claim','evidence','event','premises'},'c0 schema')
    require(c0['id']=='c0' and c0['source_sha256']==sha(p) and c0['event']==1,'c0 identity')
    require(c0['claim']=='SOURCE_HAS_DISTINCTION_AND_SECOND_LEVEL','c0 wrong claim')
    require(c0['premises']==['source_bytes','fixed_verifier_rules'],'c0 premises')
    require(len(c0['evidence'])==2,'c0 evidence count')
    for key,entry in zip(['DISTINCTION','SECOND_LEVEL'],c0['evidence']):
        require(check_span(p,entry)==key and entry['value']==REQUIRED[key],'c0 claim not proved by source')
    # SA8: no target premise, no self label, and witness illustrating non-equivalence.
    require('VGPSA' not in c0['claim'] and 'NOT_' not in c0['claim'],'c0 merely repeats target')
    require(b['nontriviality']=={'claim_is_not_target':True,'countermodel':'SAME_SOURCE_NO_ACCEPTED_RECORDS'},'nontriviality witness')
    require(all(k!='TARGET' for k in ['DISTINCTION','SECOND_LEVEL']),'target-smuggling premise')
    # SA7: replay receipt checks and event sequence before accepting the meta-receipt.
    r0=b['r0'];require(set(r0)=={'id','source_sha256','claim','certificate_sha256','verdict','verifier_id','event'},'r0 schema')
    require(r0=={'id':'r0','source_sha256':sha(p),'claim':c0['claim'],'certificate_sha256':digest(c0),'verdict':'ACCEPT','verifier_id':'V0_2','event':2},'r0 is not a valid receipt for recomputed ACCEPT(c0)')
    c1=b['c1'];require(set(c1)=={'id','source_sha256','claim','witness_id','witness_sha256','first_cert_sha256','event','premises'},'c1 schema')
    require(c1=={'id':'c1','source_sha256':sha(p),'claim':'ACTUAL_R0_IS_ACCEPTED','witness_id':'r0','witness_sha256':digest(r0),'first_cert_sha256':digest(c0),'event':3,'premises':['accepted_r0','fixed_verifier_rules']},'c1 not about actual verified r0')
    r1=b['r1'];require(set(r1)=={'id','source_sha256','claim','certificate_sha256','first_record_sha256','verdict','verifier_id','event'},'r1 schema')
    require(r1=={'id':'r1','source_sha256':sha(p),'claim':c1['claim'],'certificate_sha256':digest(c1),'first_record_sha256':digest(r0),'verdict':'ACCEPT','verifier_id':'V0_2','event':4},'r1 does not evidence accepted c1')
    expected_trace=[{'event':i,'type':typ,'sha256':digest(obj)} for i,(typ,obj) in enumerate([('MODEL',M),('CERTIFICATE_C0',c0),('ACCEPTED_R0',r0),('CERTIFICATE_C1',c1),('ACCEPTED_R1',r1)])]
    require(b['trace']==expected_trace,'trace does not certify time order or record existence')
    return {'SA'+str(i):'PASS' for i in range(1,9)}

def main():
    path=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'certificate_package.json'
    b=json.loads(path.read_text('ascii'))
    try:
        checks=verify(b)
        print('ACCEPT: all eight SA clauses independently rechecked')
        print('SOURCE_SHA256='+b['source_sha256'])
        print('PACKAGE_SHA256='+sha(path.read_bytes()))
        print('CHECKER_SHA256='+sha(pathlib.Path(__file__).read_bytes()))
        for k,v in checks.items():print(k+'='+v)
    except (ValueError, KeyError, TypeError, AssertionError, UnicodeError, OSError) as e:
        print('REJECT: '+str(e),file=sys.stderr)
        return 1
    return 0

if __name__=='__main__':sys.exit(main())
