#!/usr/bin/env python3
"""Producer for the NEW VGPSA finite witness. Not the historical 2026-09-29 run."""
import hashlib, json, pathlib

HERE = pathlib.Path(__file__).resolve().parent
P = (HERE/'prompt_P_star.txt').read_bytes()
S = P.decode('ascii')

def sha(b): return hashlib.sha256(b).hexdigest()
def enc(x): return json.dumps(x, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode('ascii')
def digest(x): return sha(enc(x))
def data():
    d={}
    for line in S.splitlines():
        k,v=line.split('=',1)
        assert k not in d
        d[k]=v
    return d
D = data()

def span(key):
    literal = (key+'='+D[key]).encode('ascii')
    pos=P.find(literal)
    assert pos>=0 and P.find(literal,pos+1)<0
    return {'key':key,'value':D[key],'start':pos,'end':pos+len(literal)}

# L1-L8 are source facts, not a proof that the corresponding actions happened.
keys=['TARGET','INSPECTION','MODEL','DISTINCTION','SECOND_LEVEL','FIRST_CERT','SECOND_CERT','NONTRIVIAL']
lemmas=[{'name':'L'+str(i+1), 'evidence':span(k),'kind':'source_fact'} for i,k in enumerate(keys)]
model=[span(k) for k in ['TARGET','INSPECTION','MODEL','DISTINCTION','FIRST_CERT','SECOND_LEVEL']]
Pprime=S.replace('SECOND_LEVEL=CERTIFY_ACTUAL_ACCEPTED_R0','SECOND_LEVEL=STOP_AFTER_R0').replace('SECOND_CERT=CHECK_RECEIPT_OF_ACTUAL_R0','SECOND_CERT=NOT_REQUIRED').replace('SETTLEMENT=REFUTE_ONLY_AFTER_TWO_VERIFIED_RECORDS','SETTLEMENT=STOP_AFTER_FIRST_VERIFIED_RECORD')
assert Pprime!=S

c0={'id':'c0','source_sha256':sha(P),'claim':'SOURCE_HAS_DISTINCTION_AND_SECOND_LEVEL',
    'evidence':[span('DISTINCTION'),span('SECOND_LEVEL')],'event':1,
    'premises':['source_bytes','fixed_verifier_rules']}
r0={'id':'r0','source_sha256':sha(P),'claim':c0['claim'],
    'certificate_sha256':digest(c0),'verdict':'ACCEPT','verifier_id':'V0_2','event':2}
c1={'id':'c1','source_sha256':sha(P),'claim':'ACTUAL_R0_IS_ACCEPTED',
    'witness_id':'r0','witness_sha256':digest(r0),'first_cert_sha256':digest(c0),
    'event':3,'premises':['accepted_r0','fixed_verifier_rules']}
r1={'id':'r1','source_sha256':sha(P),'claim':c1['claim'],'certificate_sha256':digest(c1),
    'first_record_sha256':digest(r0),'verdict':'ACCEPT','verifier_id':'V0_2','event':4}
trace=[{'event':0,'type':'MODEL','sha256':digest(model)},
       {'event':1,'type':'CERTIFICATE_C0','sha256':digest(c0)},
       {'event':2,'type':'ACCEPTED_R0','sha256':digest(r0)},
       {'event':3,'type':'CERTIFICATE_C1','sha256':digest(c1)},
       {'event':4,'type':'ACCEPTED_R1','sha256':digest(r1)}]
package={'schema':'VGPSA_FINITE_V0_2','historical_run':False,'source':S,'source_sha256':sha(P),
         'counterfactual_source':Pprime,'model':model,'lemmas':lemmas,'c0':c0,'r0':r0,
         'c1':c1,'r1':r1,'trace':trace,
         'execution':{'tag':'X_EXECUTION','producer':'build_witness.py'},
         'verifier':{'tag':'V_VERIFIER','checker':'independent_verifier.py',
                     'checker_sha256':sha((HERE/'independent_verifier.py').read_bytes())},
         'nontriviality':{'claim_is_not_target':True,'countermodel':'SAME_SOURCE_NO_ACCEPTED_RECORDS'}}
(HERE/'certificate_package.json').write_bytes(json.dumps(package,sort_keys=True,indent=2).encode('ascii')+b'\n')
print('Created NEW (not historical) package')
print('source sha256',sha(P))
print('package sha256',sha((HERE/'certificate_package.json').read_bytes()))
