#!/usr/bin/env python3
"""Adversarial smoke tests: mutate evidence, receipts, chronology, or source."""
import copy,json,subprocess,pathlib,sys
HERE=pathlib.Path(__file__).resolve().parent
orig=json.loads((HERE/'certificate_package.json').read_text())

def run(title, mutate):
    b=copy.deepcopy(orig);mutate(b)
    out=HERE/('_negative_'+title+'.json')
    out.write_text(json.dumps(b, sort_keys=True))
    p=subprocess.run([sys.executable,str(HERE/'independent_verifier.py'),str(out)],capture_output=True,text=True)
    out.unlink()
    if p.returncode!=1:
        raise AssertionError(title+' unexpectedly accepted: '+p.stdout+' '+p.stderr)
    print('REJECTED:',title,'-',p.stderr.strip())

cases=[
('missing_r0',lambda b:b.pop('r0')),
('forged_r0_verdict',lambda b:b['r0'].__setitem__('verdict','REJECT')),
('wrong_c0_byte_span',lambda b:b['c0']['evidence'][0].__setitem__('start',b['c0']['evidence'][0]['start']+1)),
('wrong_counterfactual',lambda b:b.__setitem__('counterfactual_source',b['source'])),
('false_source',lambda b:b.__setitem__('source',b['source'].replace('SECOND_LEVEL=CERTIFY_ACTUAL_ACCEPTED_R0','SECOND_LEVEL=STOP_AFTER_R0'))),
('forged_c1_reference',lambda b:b['c1'].__setitem__('witness_sha256','0'*64)),
('swapped_chronology',lambda b:b['r1'].__setitem__('event',1)),
('forged_lemma',lambda b:b['lemmas'][3]['evidence'].__setitem__('value','I_AM_SELF_AWARE')),
]
for name,fn in cases:run(name,fn)
print('PASS: all 8 adversarial alterations were rejected')
