DNI VERSION 0.2 - PROVISIONAL PUBLICATION PACKAGE
Main paper: PROVISIONAL- DNI_Deterministic_Nondeterministic_Interface_Theory_v0_2_ATLAS_Repaired.pdf and .tex
Additional: ATLAS reaudit, Version 0.1 history, two verification scripts and outputs.
The main PDF and main LaTeX filenames begin with the exact requested prefix PROVISIONAL- (including the following space).
PDFs are freshly typeset from the supplied LaTeX sources for this site; therefore PDF binary hashes may differ from the earlier local files.
Restricted scope: classical finite-state deterministic/possibilistic/Markov interfaces.
The audited finite-state theorems do not establish a general physical unification, a universal theory-of-theories amalgam, or a novelty claim.
